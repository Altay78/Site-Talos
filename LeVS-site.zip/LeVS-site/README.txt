LE VS — SITE VITRINE (v1.2)
============================

CONTENU
-------
index.html  · Page d'accueil
menu.html   · La carte (43 plats)
styles.css  · Feuille de style
app.js      · Interactions

NOUVEAUTÉS v1.2
---------------
- Logo Le VS carré (timbre vintage : MAISON · Le VS · EST. 2014 ·
  PIZZA · KEBAB · BURGER · TACOS)
- Mobile densifié : hero plus court, catégories en 2 colonnes,
  contact en 2 colonnes, padding sections réduit
- Barre d'action mobile fixe en bas de l'écran : Appeler · La
  carte · Réserver — toujours à portée de pouce
- Hero visual masqué sur très petits écrans (<480px)
- Carte : items plus compacts, paddings serrés

POUR OUVRIR
-----------
Double-clic sur index.html.

POUR METTRE EN LIGNE (le plus simple)
--------------------------------------
1. Allez sur https://app.netlify.com/drop
2. Glissez le dossier dézippé sur la page
3. C'est en ligne — vous avez une URL .netlify.app en 30 secondes

À PERSONNALISER AVANT MISE EN LIGNE
------------------------------------
- Téléphone "01 00 00 00 00" → votre numéro
  (chercher "tel:+33100000000" dans les .html)
- Adresse "12 rue de la République 75011 Paris"
- Email "bonjour@levs.fr"
- Liens réseaux sociaux
- Photos Unsplash → vos photos
