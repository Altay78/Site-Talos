LE VS — SITE VITRINE (v1.1)
============================

CONTENU
-------
index.html  · Page d'accueil
menu.html   · La carte (43 plats — à remplacer par la vraie)
styles.css  · Feuille de style
app.js      · Interactions

NOUVEAU DANS CETTE VERSION
--------------------------
- Frites maison cuites à la graisse de bœuf, signalées:
  · bandeau défilant en haut de chaque page
  · pilier "Fait maison" sur la landing
  · descriptions de tous les plats avec frites

POUR OUVRIR
-----------
Double-clic sur index.html.

POUR METTRE EN LIGNE
--------------------
Netlify Drop (gratuit, 30s): https://app.netlify.com/drop
Glissez le dossier — c'est en ligne.
