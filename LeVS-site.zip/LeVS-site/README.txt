LE VS — SITE VITRINE (v1)
=========================

CONTENU
-------
index.html  · Page d'accueil (hero, catégories, signatures, histoire, contact)
menu.html   · La carte complète (43 plats, 6 catégories)
styles.css  · Feuille de style (palette, typographies, animations)
app.js      · Interactions (nav, scroll reveal, filtre catégories)


COMMENT OUVRIR
--------------
Double-cliquez sur "index.html" — ça s'ouvre dans votre navigateur.
Pour une preview parfaite (polices Google chargées en CDN), assurez-vous
d'être connecté à internet la première fois.


COMMENT METTRE EN LIGNE
-----------------------
1. Hébergement gratuit recommandé : Netlify (drag & drop du dossier),
   Vercel, GitHub Pages, ou OVH/Gandi/Hostinger pour un nom de domaine
   personnalisé.
2. Glissez tout le contenu du dossier à la racine de l'hébergement.
3. C'est en ligne — aucune configuration serveur nécessaire.


À PERSONNALISER AVANT MISE EN LIGNE
-----------------------------------
- Téléphone "01 00 00 00 00" → remplacez par votre vrai numéro
  (cherchez "tel:+33100000000" dans les fichiers .html)
- Adresse "12 rue de la République 75011 Paris" → votre adresse réelle
  (cherchez dans index.html section CONTACT)
- Email "bonjour@levs.fr" → votre email
- Liens Instagram/Facebook/TikTok → vos vrais comptes
- Photos : actuellement Unsplash. Pour de meilleurs résultats,
  remplacez par vos photos (cherchez "https://images.unsplash.com"
  dans les .html et changez l'URL)
- Horaires : section CONTACT de index.html

DESIGN
------
Palette : crème papier, brun café, bronze doré (inspirée du poster)
Polices : Playfair Display (titres), Pinyon Script (signature), Inter (texte)
Responsive : optimisé pour mobile, tablette, desktop.

